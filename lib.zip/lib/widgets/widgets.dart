export 'package:flutter_application_2/widgets/drawer_menu.dart';

export 'package:flutter_application_2/widgets/container1_1.dart';
export 'package:flutter_application_2/widgets/container1_2.dart';
export 'package:flutter_application_2/widgets/container1_3.dart';

export 'package:flutter_application_2/widgets/container2_1.dart';
export 'package:flutter_application_2/widgets/container2_2.dart';
export 'package:flutter_application_2/widgets/container2_3.dart';

export 'package:flutter_application_2/widgets/container_training.dart';
export 'package:flutter_application_2/widgets/container_coaching.dart';
export 'package:flutter_application_2/widgets/container_podcast.dart';
export 'package:flutter_application_2/widgets/container_about.dart';
export 'package:flutter_application_2/widgets/container_youtube.dart';
export 'package:flutter_application_2/widgets/container_archive.dart';

export 'package:flutter_application_2/widgets/bottom_menu.dart';